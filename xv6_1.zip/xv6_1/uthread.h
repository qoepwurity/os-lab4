// uthread.h
#ifndef UTHREAD_H
#define UTHREAD_H

void uthread_init(void (*s)());
void yield(void);

#endif